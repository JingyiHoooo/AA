import dropbox
import datetime
import schedule
import numpy as np
import string
import requests
import time
import sys
import os
import csv
import sqlite3
import math
import random
import codecs
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
from threading import Timer
from matplotlib.ticker import MultipleLocator
from matplotlib.ticker import FormatStrFormatter


class EBikeData_Getting:
        
    def EBike(x_t,y_hP):
        # Dropbox access token    
        dbx = dropbox.Dropbox('lY_d3DAmzgAAAAAAAAAAs2SoAOwHmVVqP5ozJcw4sDBPvIdzSSwISAjUuy1eDLt4')

        # Set parameters for downloading the file 
        # Saving path
        save_path = 'C:\\FINAL_PROJECT\\EBike_Files\\Data.db'
        # File location in dropbox    
        path = '/EBIKE.db'

         # current time
        timestamp = datetime.datetime.now()
        # time gap
        delta = datetime.timedelta(minutes = 1)
        # time where the IBI file has been bulit
        filetime = timestamp - delta

        # Re-formatting: datetime->String
        timeframe = filetime.strftime('%Y-%m-%d %H:%M')
        csv_filetime = filetime.strftime('%Y-%m-%d-%H-%M')
        #res = dbx.files_list_folder(path,None)
        #print (res)
        # try download
        try:
            dbx.files_download_to_file(save_path,path,None)   
        except:
                print('Database current is not exsit')
                pass
        else:
            print("Successful Downloading database file from Dropbox, overwriting " + save_path + "...")

            # Save voltage of the motor and data which averaged
            conn = sqlite3.connect(save_path)
            cursor = conn.cursor()

            #timeframe = '2019-07-19 19:28'
            try:
                res_findData=cursor.execute("SELECT * FROM bikeData WHERE time LIKE '%%%s%%'" %timeframe) # find "key words" in column time of table bikeData
            except:
                print('try dump')
                conn.close()
                time.sleep(10)
                dbx.files_download_to_file(save_path,path,None)
                print('redownload')
                conn = sqlite3.connect(save_path)
                cursor = conn.cursor()

            if cursor.fetchone() is None:   # No corresponding data to the time, need Optimize
                count = 0
                print('Not Found')
                pass
            else:                   # Have such data
                rows = cursor.fetchall()

                sum_hP = 0
                sum_ThrOut = 0
                count = 0

                for row in rows:
                    sum_hP += row[9]
                    sum_ThrOut += row[12]
                    count += 1

            conn.close()

            if count == 0:
                pass

            else:
                ave_hP = sum_hP/count
                d5_hP = int(ave_hP/5)
                ave_ThrOut = sum_ThrOut/count
                d5_ThrOut = int(ave_ThrOut/5)
                # export the data processed into file "export_EBikedata.csv"

                x_t.append(timeframe)
                y_hP.append(ave_hP)

                fig = EBikeData_Getting.draw(x_t, y_hP)

                with open("export_EBikedata.csv", "a", newline='') as f:
                    headers = ['time', 'average humanPower', 'D5 humanPower','average ThrottleOutput','D5 ThrottleOutput' ]
                    writer = csv.writer(f)

                    if not os.path.getsize("export_EBikedata.csv"):         
                        # print('no headers')
                        writer.writerow(headers) # file doesn't exist yet, write a header

                    # print('have headers')
                    writer.writerow([csv_filetime,ave_hP,d5_hP,ave_ThrOut,d5_ThrOut])
                    # Remove duplicates
                    # pd.read_csv("export_EBikedata.csv").drop_duplicates(subset ="First Name",keep = False, inplace = True)
                    f.close()
                
    def StartEBike():
        x_t = []
        y_hP = []
        schedule.every(1).minutes.do(EBikeData_Getting.EBike,x_t,y_hP)
        while True:
            schedule.run_pending()
            
    def draw(x_t, y_hP):
        plt.clf()
        plt.plot(x_t, y_hP, '-r')
        plt.tick_params(axis='x', rotation=45)
        plt.title('human power verus time')
        plt.xlabel('time')
        plt.ylabel('human power')
        plt.pause(0.01)  # pause a bit so that plots are updated
            
if __name__ == "__main__":
    schedule.clear()
    EBikeData_Getting.StartEBike()
    print ('here')