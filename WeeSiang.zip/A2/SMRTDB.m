/*
*  Line 84- 214 from original databaseService.java class which are modified
*/

private void registerDatabaseReceiver() {
        Log.d(tag, "db reg");
        filter = new IntentFilter("ie.ucd.smartrideRT.database");
        registerReceiver(MyReceiver, filter);

    }
    int minute = -1;
    private final BroadcastReceiver MyReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(tag, "db onreceive");
            String bikeDataReceived = intent.getStringExtra("database");

            //comment this log line for now but it is very useful for checking data is being received
            Log.i(tag, "DS: Bike data: " + bikeDataReceived);

            // Must determine which table the data is intended for
            String[] splitBikeDataReceived = bikeDataReceived.split(" ");

            Calendar c = Calendar.getInstance();

            int currentMinute = c.get(Calendar.MINUTE);
            if (minute == -1)
                minute = currentMinute;
            if (currentMinute != minute) {
                minute = currentMinute;
                UploadBikeDataThread uploadBikeDaraThread = new UploadBikeDataThread();
                uploadBikeDaraThread.start();
                }

            else{
                if(splitBikeDataReceived[0].equals("Signal")){
                ProcessTrafficLightDataThread processTrafficLightDataThread = new ProcessTrafficLightDataThread(bikeDataReceived);
                processTrafficLightDataThread.start();
                }
                else {
                        //If it is desired to save the frequency with which data is saved from cycle analyst this can be
                        //implemented here with a count variable as is done in mHeartRateEventListener below
                        ProcessBikeDataThread processBikeDataThread = new ProcessBikeDataThread(bikeDataReceived);
                        processBikeDataThread.start();
                    }
                }
        }
    };


    private class UploadBikeDataThread extends Thread{
        public void run(){
            try {
                Upload.upload("EBike");
                Log.d(tag,"Success Call Upload here"+ minute);
            } catch (Exception e) {
                System.out.println("Call upload exception");
                return;
            }
        }
    }

    //Save data from the cycle analyst in a separate thread
    private class ProcessBikeDataThread extends Thread{
        private final String bikeDataString;

        private final Object o = new Object();

        public ProcessBikeDataThread(String string){
            this.bikeDataString = string;
            // this.count = count;
        }

        public void run(){
            String[] strings;
            String tempFlag="";
            Float[] floats = new Float[13];

            strings = bikeDataString.split("\\t");


            //Cycle analyst outputs 13 variables
            for(int i=0;i<13;i++){
                //The last variable "flag" is sometimes a string if there is a warning e.g. it could be "1W"
                //as such must be processed as a string, see cycle analyst guide
                if(i==12){
                    try{
                        tempFlag = strings[i];
                    } catch (ArrayIndexOutOfBoundsException e){
                        tempFlag = "1M";
                    }
                }
                else{
                    try{
                        floats[i] = Float.valueOf(strings[i]);
                    } catch (NumberFormatException e){
                        e.printStackTrace();
                        return;
                    }

                }
            }

            float batteryEnergy = floats[0];
            float voltage = floats[1];
            float current = floats[2];
            float speed = floats[3];
            float distance = floats[4];
            float temperature = floats[5];
            float RPM = floats[6];
            float humanPower = floats[7];
            float torque = floats[8];
            float throttleIn = floats[9];
            float throttleOut = floats[10];
            float acceleration = floats[11];
            String flag = tempFlag;

            BikeData bikedata = new BikeData(batteryEnergy, voltage, current, speed, distance,temperature,
                    RPM, humanPower, torque, throttleIn, throttleOut, acceleration, flag);

            /*
            synchronized (o) {
                dbHandler.addBikeDataRow(bikedata);
            }
            */
            try{
            dbHandler.addBikeDataRow(bikedata);
            Log.d(tag,"ROWWWWWW");
            } catch(Exception e){
                Log.d(tag,"SQLiteConnectionPool Error");
                return;
            }
        }
    }