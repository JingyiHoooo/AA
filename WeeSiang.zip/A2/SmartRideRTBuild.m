apply plugin: 'com.android.application'

android {
    compileSdkVersion 28

    defaultConfig {
        applicationId "ie.ucd.smartrideRT"
        minSdkVersion 19
        targetSdkVersion 28
        versionCode 1
        versionName "1.0"
        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
        multiDexEnabled true
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
        debug{
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }

    packagingOptions {
        exclude 'META-INF/LICENSE'
        exclude 'META-INF/DEPENDENCIES'
        exclude 'META-INF/proguard/androidx-annotations.pro'
    }
}

repositories{
    maven { url 'https://jitpack.io' }
    flatDir {
        dirs 'libs'
    }
}

dependencies {
    implementation(name:'pathsense-android-sdk-location-bundle-release-4.0.0.0', ext:'aar')
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    implementation 'androidx.core:core:1.0.1'
    testImplementation('androidx.test.espresso:espresso-core:3.2.0-alpha04', {
        exclude group: 'com.android.support', module: 'support-annotations'
    })
    implementation 'androidx.appcompat:appcompat:1.1.0-alpha04'
    implementation 'com.google.android.gms:play-services-location:15.0.1'
    implementation 'com.google.android.gms:play-services-maps:9.6.0'
    implementation 'com.google.android.material:material:1.1.0-alpha05'
    implementation('com.google.android.gms:play-services-identity:10.0.1') {
        exclude module: 'support-v4'
    }
    implementation('com.google.android.gms:play-services-plus:10.0.1') {
        exclude module: 'support-v4'
    }
    implementation 'com.github.PhilJay:MPAndroidChart:v3.1.0-alpha'
    implementation('com.google.android.gms:play-services-gcm:10.0.1') {
        exclude module: 'support-v4'
    }
    testImplementation 'junit:junit:4.12'
    implementation files('libs/microsoft-band-1.3.20307.2.jar')
    implementation files('libs/Messaging.jar')

    implementation 'com.dropbox.core:dropbox-core-sdk:3.1.1'
    implementation 'com.android.support:multidex:1.0.3'
}