apply plugin: 'com.android.application'

android {
    compileSdkVersion 28
    buildToolsVersion '28.0.3'
    defaultConfig {
        applicationId 'com.empatica.empalinksample'
        minSdkVersion 19
        targetSdkVersion 27
        versionCode 2323
        versionName "1.1"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
    productFlavors {
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_7
        targetCompatibility JavaVersion.VERSION_1_7
    }
}



dependencies {
    implementation fileTree(include: ['*.jar'], dir: 'libs')
    //implementation 'com.android.support:appcompat-v7:27.1.1'
    implementation 'com.empatica.empalink:empalink:2.2@aar'
    implementation 'com.squareup.okhttp:okhttp:2.5.0'

    implementation "com.android.support:support-compat:28.0.0"
    implementation 'com.android.support:appcompat-v7:28.0.0'

    implementation 'com.dropbox.core:dropbox-core-sdk:3.1.1'

}